import { createHash, randomUUID } from 'node:crypto';
import { Pool } from 'pg';
import { z } from 'zod';
export type LearningKind = 'course' | 'webinar' | 'mentorship' | 'career';
const eventKey = z.string().regex(/^[a-z][a-z0-9_.-]{0,63}$/);
export const analyticsSchema = z.object({ event: eventKey, screen: eventKey, itemKind: z.enum(['course', 'webinar', 'mentorship', 'career']).optional() }).strict();
export type AnalyticsEvent = z.infer<typeof analyticsSchema>;

export interface DatabaseActor { orgId: string; accountId: string; requestId: string; issuer?: string }
export interface QueryResult { rows: Record<string, unknown>[]; rowCount: number | null }
export interface DatabaseClient { query(sql: string, values?: unknown[]): Promise<QueryResult>; release(): void }
export interface AppDatabase { connect(): Promise<DatabaseClient> }
export interface Enrollment { id: string; kind: LearningKind; itemRef: string; status: 'active' | 'completed' | 'withdrawn'; createdAt: string }
export interface LessonProgress { enrollmentId: string; lessonRef: string; status: 'started' | 'completed'; version: number; updatedAt: string }
export class LearningError extends Error {
  constructor(public readonly code: string, public readonly status: number) { super(code); this.name = 'LearningError'; }
}
const ref = z.string().trim().min(1).max(180).regex(/^[^\u0000-\u001f\u007f]+$/);
const actorSchema = z.object({ orgId: ref, accountId: ref, requestId: ref, issuer: ref.default('canonical') });
const itemSchema = z.object({ kind: z.enum(['course', 'webinar', 'mentorship', 'career']), id: ref }).strict();
const progressSchema = z.object({ enrollmentId: z.uuid(), lessonRef: ref, status: z.enum(['started', 'completed']), expectedVersion: z.number().int().min(0).max(2147483646) }).strict();
const hash = (value: unknown) => createHash('sha256').update(JSON.stringify(value)).digest('hex');
const time = (value: unknown) => value instanceof Date ? value.toISOString() : String(value);
const enrollment = (row: Record<string, unknown>): Enrollment => ({ id: String(row.id), kind: row.item_kind as LearningKind, itemRef: String(row.item_ref), status: row.status as Enrollment['status'], createdAt: time(row.created_at) });
const progress = (row: Record<string, unknown>): LessonProgress => ({ enrollmentId: String(row.enrollment_id), lessonRef: String(row.lesson_ref), status: row.status as LessonProgress['status'], version: Number(row.version), updatedAt: time(row.updated_at) });

/** Use a request-scoped pool through Hyperdrive; caller must close it afterward.
 * No process environment, direct connection fallback, query cache, or memory store. */
export function createDatabase(connectionString: string): Pool {
  return new Pool({ connectionString, max: 2, connectionTimeoutMillis: 5000, idleTimeoutMillis: 1000, statement_timeout: 10000 });
}

/** This repository accepts only server-resolved canonical actor IDs. Learning
 * tracking never grants paid content, webinar seats, or certificate eligibility. */
export class LearningRepository {
  constructor(private readonly database: AppDatabase) {}
  private async transaction<T>(inputActor: DatabaseActor, work: (client: DatabaseClient, actor: DatabaseActor) => Promise<T>): Promise<T> {
    const actor = actorSchema.parse(inputActor);
    const client = await this.database.connect();
    try {
      await client.query('BEGIN');
      await client.query("SET LOCAL lock_timeout='5s'");
      await client.query("SET LOCAL statement_timeout='10s'");
      await client.query("SELECT set_config('techlyup.org_id',$1,true),set_config('techlyup.account_id',$2,true)", [actor.orgId, actor.accountId]);
      const reference = (await client.query('SELECT issuer FROM learning_core.account_refs WHERE org_id=$1 AND account_id=$2', [actor.orgId, actor.accountId])).rows[0];
      if (reference && reference.issuer !== actor.issuer) throw new LearningError('identity_reference_conflict', 403);
      const result = await work(client, actor);
      await client.query('COMMIT'); return result;
    } catch (error) { await client.query('ROLLBACK').catch(() => undefined); throw error; }
    finally { client.release(); }
  }
  private async ensureReference(client: DatabaseClient, actor: DatabaseActor) {
    await client.query('INSERT INTO learning_core.account_refs(org_id,account_id,issuer) VALUES($1,$2,$3) ON CONFLICT DO NOTHING', [actor.orgId, actor.accountId, actor.issuer ?? 'canonical']);
    const reference = (await client.query('SELECT issuer FROM learning_core.account_refs WHERE org_id=$1 AND account_id=$2', [actor.orgId, actor.accountId])).rows[0];
    if (!reference || reference.issuer !== (actor.issuer ?? 'canonical')) throw new LearningError('identity_reference_conflict', 403);
  }
  private async operation<T extends object>(actor: DatabaseActor, key: string, kind: string, input: unknown, work: (client: DatabaseClient, validated: DatabaseActor) => Promise<T>): Promise<T> {
    z.uuid().parse(key); const digest = hash({ kind, input });
    return this.transaction(actor, async (client, validated) => {
      await client.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))', [JSON.stringify([validated.orgId, validated.accountId, key])]);
      const prior = (await client.query('SELECT request_sha256,result FROM learning_core.idempotency_operations WHERE org_id=$1 AND account_id=$2 AND operation_key=$3', [validated.orgId, validated.accountId, key])).rows[0];
      if (prior) {
        if (prior.request_sha256 !== digest) throw new LearningError('idempotency_conflict', 409);
        return prior.result as T;
      }
      await this.ensureReference(client, validated);
      const result = await work(client, validated);
      await client.query('INSERT INTO learning_core.idempotency_operations(org_id,account_id,operation_key,operation_kind,request_sha256,result) VALUES($1,$2,$3,$4,$5,$6::jsonb)', [validated.orgId, validated.accountId, key, kind, digest, JSON.stringify(result)]);
      return result;
    });
  }
  private async audit(client: DatabaseClient, actor: DatabaseActor, action: string, aggregateId: string, metadata: object) {
    await client.query('INSERT INTO learning_core.audit_events(id,org_id,account_id,request_id,action,aggregate_id,metadata) VALUES($1,$2,$3,$4,$5,$6,$7::jsonb)', [randomUUID(), actor.orgId, actor.accountId, actor.requestId, action, aggregateId, JSON.stringify(metadata)]);
  }
  async enroll(actor: DatabaseActor, itemRef: { kind: LearningKind; id: string }, idempotencyKey: string): Promise<Enrollment> {
    const item = itemSchema.parse(itemRef);
    return this.operation(actor, idempotencyKey, 'enroll', item, async (client, validated) => {
      const inserted = await client.query('INSERT INTO learning_core.learning_enrollments(id,org_id,account_id,item_kind,item_ref) VALUES($1,$2,$3,$4,$5) ON CONFLICT(org_id,account_id,item_kind,item_ref) DO NOTHING RETURNING *', [randomUUID(), validated.orgId, validated.accountId, item.kind, item.id]);
      const row = inserted.rows[0] ?? (await client.query('SELECT * FROM learning_core.learning_enrollments WHERE org_id=$1 AND account_id=$2 AND item_kind=$3 AND item_ref=$4', [validated.orgId, validated.accountId, item.kind, item.id])).rows[0];
      if (inserted.rows.length) await this.audit(client, validated, 'learning.enrolled', String(row.id), { kind: item.kind, itemRef: item.id });
      return enrollment(row);
    });
  }
  async listEnrollments(actor: DatabaseActor): Promise<Enrollment[]> {
    return this.transaction(actor, async (client, validated) => (await client.query('SELECT * FROM learning_core.learning_enrollments WHERE org_id=$1 AND account_id=$2 ORDER BY created_at DESC,id LIMIT 100', [validated.orgId, validated.accountId])).rows.map(enrollment));
  }
  async saveProgress(actor: DatabaseActor, input: { enrollmentId: string; lessonRef: string; status: 'started' | 'completed'; expectedVersion: number }, idempotencyKey: string): Promise<LessonProgress> {
    const value = progressSchema.parse(input);
    return this.operation(actor, idempotencyKey, 'save_progress', value, async (client, validated) => {
      const owner = (await client.query('SELECT status FROM learning_core.learning_enrollments WHERE org_id=$1 AND account_id=$2 AND id=$3 FOR UPDATE', [validated.orgId, validated.accountId, value.enrollmentId])).rows[0];
      if (!owner) throw new LearningError('enrollment_not_found', 404);
      if (owner.status !== 'active') throw new LearningError('enrollment_inactive', 409);
      const prior = (await client.query('SELECT * FROM learning_core.learning_progress WHERE org_id=$1 AND account_id=$2 AND enrollment_id=$3 AND lesson_ref=$4', [validated.orgId, validated.accountId, value.enrollmentId, value.lessonRef])).rows[0];
      if ((prior ? Number(prior.version) : 0) !== value.expectedVersion) throw new LearningError('version_conflict', 409);
      if (prior?.status === 'completed' && value.status !== 'completed') throw new LearningError('progress_regression', 409);
      const saved = await client.query('INSERT INTO learning_core.learning_progress(org_id,account_id,enrollment_id,lesson_ref,status,version) VALUES($1,$2,$3,$4,$5,1) ON CONFLICT(org_id,account_id,enrollment_id,lesson_ref) DO UPDATE SET status=excluded.status,version=learning_core.learning_progress.version+1,updated_at=now() RETURNING *', [validated.orgId, validated.accountId, value.enrollmentId, value.lessonRef, value.status]);
      await this.audit(client, validated, 'learning.progress_saved', value.enrollmentId, { lessonRef: value.lessonRef, status: value.status, version: Number(saved.rows[0].version) });
      return progress(saved.rows[0]);
    });
  }
  async listProgress(actor: DatabaseActor, enrollmentId: string): Promise<LessonProgress[]> {
    z.uuid().parse(enrollmentId);
    return this.transaction(actor, async (client, validated) => (await client.query('SELECT * FROM learning_core.learning_progress WHERE org_id=$1 AND account_id=$2 AND enrollment_id=$3 ORDER BY updated_at DESC,lesson_ref LIMIT 200', [validated.orgId, validated.accountId, enrollmentId])).rows.map(progress));
  }
  async recordAnalytics(actor: DatabaseActor, event: AnalyticsEvent, eventId: string): Promise<{ eventId: string; duplicate: boolean }> {
    const value = analyticsSchema.parse(event); z.uuid().parse(eventId); const digest = hash(value);
    return this.transaction(actor, async (client, validated) => {
      await this.ensureReference(client, validated);
      const saved = await client.query('INSERT INTO learning_core.analytics_events(event_id,org_id,account_id,event_name,screen,item_kind,request_sha256) VALUES($1,$2,$3,$4,$5,$6,$7) ON CONFLICT DO NOTHING RETURNING event_id', [eventId, validated.orgId, validated.accountId, value.event, value.screen, value.itemKind ?? null, digest]);
      if (saved.rows.length) return { eventId, duplicate: false };
      const prior = (await client.query('SELECT request_sha256 FROM learning_core.analytics_events WHERE org_id=$1 AND account_id=$2 AND event_id=$3', [validated.orgId, validated.accountId, eventId])).rows[0];
      if (prior?.request_sha256 !== digest) throw new LearningError('event_conflict', 409);
      return { eventId, duplicate: true };
    });
  }
}
