# Reusable learning PostgreSQL foundation

This package owns only the new `learning_core` schema. Canonical accounts, passwords, profiles, permissions, registration/payment eligibility and content remain with their existing owner services. `account_refs` stores an external subject reference, never credentials. This library has no application/mobile contracts dependency and does not introduce a second identity database.

## Integration contract

Import `LearningRepository` and `createDatabase` from `@appneurox/learning-postgres`. Resolve `DatabaseActor { orgId, accountId, requestId, issuer? }` on the server from the authenticated canonical session. Never take tenant/account IDs or roles from a client request body. The repository only reads/writes that actor's own rows, including for administrators; no implicit global-admin bypass exists. Set `issuer` explicitly to the trusted identity realm; it defaults to `canonical` for single-realm integrations. A stored tenant/account reference is pinned to one issuer. Supplying the same ID from a different realm fails with `identity_reference_conflict`; it never links accounts by email or silently merges subjects.

- `enroll(actor, { kind, id }, idempotencyKey)` creates app learning tracking for a stable external learning reference.
- `listEnrollments(actor)` returns at most the 100 most recent owned enrollments.
- `saveProgress(actor, { enrollmentId, lessonRef, status, expectedVersion }, idempotencyKey)` records self-reported lesson progress. Use version 0 for a new lesson; subsequent writes require the returned version. Completed lessons cannot regress.
- `listProgress(actor, enrollmentId)` returns at most 200 owned lesson records.
- `recordAnalytics(actor, event, eventId)` accepts locally owned bounded event/screen identifier fields and an optional learning-kind enum. Unknown properties such as email, URL, token or arbitrary metadata are rejected. An API must further restrict event/screen names to its published allowlist rather than putting personal values into event identifiers.

Mutation/event IDs are UUIDs. Exact retries replay safely; using an existing ID with different content returns a conflict. Enrollment/progress changes and audit receipts commit atomically. Concurrent lesson updates with the same expected version allow one winner. Enrollment tracking and self-reported progress never grant a paid course, webinar seat, media token, verified skill, or certificate. API integration must independently validate item/lesson references against the source catalog and current canonical entitlements before offering a protected learning journey.

Use the Cloudflare Hyperdrive connection string with `nodejs_compat`, a request-scoped pool (maximum two connections), no authorization query caching, and `finally { await pool.end(); }`. Attach a sanitized pool error handler. There is no direct connection or in-memory fallback. Keep optional PostgreSQL routes disabled until the owned binding and reviewed runtime grants are configured. The migration CLI uses a separate direct connection because its advisory lock requires a stable session.

## Migrations

The default plan reads local files and hashes without connecting:

```sh
npm run db:plan
```

Supply `LEARNING_POSTGRES_MIGRATION_URL` privately through your environment/secret manager. Review target identity, PostgreSQL version, TLS, backup/restore evidence and the generated plan before any remote action.

```sh
npm run check -w @appneurox/learning-postgres
npm run migrate -w @appneurox/learning-postgres
npm run check -w @appneurox/learning-postgres
```

A fresh/pending `check` exits nonzero with `pendingCount`. Review that pending-only result, explicitly apply, then require a zero-pending check. History drift, missing files, a backfilled version, an active runner, or database errors fail closed. Applied SQL is immutable. Each file and its checksum receipt share a transaction; a failure preserves earlier committed migrations. Add reviewed forward migrations or roll back application code instead of running destructive down scripts. Only the service-owned learning_core schema is targeted. Existing identity/application tables are not migrated by these commands. No deployed instance of the earlier temporary application package/schema existed; this initial service migration has only been applied to disposable acceptance databases.

The runner takes a session advisory lock, bounds SQL/lock waits, validates the whole source/history before DDL, and suppresses raw database diagnostics. Direct migration execution never provisions users, applies account backfills, or changes the current website.

## Runtime grants and RLS

`migrations/0001_learning_foundation.sql` enables and forces tenant/account RLS on every learning data table. Missing request context denies every row for a normal runtime role. Explicit owner filters remain in every repository query. The context is transaction-local and does not leak when a pooled connection is reused.

An operator must provision a distinct runtime login with `NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE`, verified TLS and no table/schema ownership. Review the role placeholder in `scripts/runtime-grants.sql` before executing that template. It grants only required DML, denies migration-ledger reads and audit updates/deletes, and grants only `UPDATE(updated_at)` on enrollments to support PostgreSQL row locks. Do not run a production app as the migration owner/superuser. Shared service credentials can set RLS context, so server authentication remains mandatory. Cross-account reporting and retention/cleanup require separate reviewed maintenance permissions; they are not exposed through the learner repository.

## Acceptance tests

```sh
npx tsx --test packages/learning-postgres/tests/*.test.ts
npm run typecheck -w @appneurox/learning-postgres
```

With local `initdb`, `pg_ctl`, and `createdb`, the tests start their own private loopback instance, then remove it afterward. Alternatively provide `LEARNING_TEST_DATABASE_URL` (`APP_TEST_DATABASE_URL` is accepted for existing CI integration) pointing to an isolated loopback database ending in `_ci`, with no query/fragment and CI owner permissions to create a temporary database/role. A PostgreSQL 18 CI service with database `learning_core_ci` works. The tests create a randomly named database and `NOSUPERUSER NOBYPASSRLS` runtime role; they drop only those resources. They reject remote/shared test URL formats. With neither an explicit isolated database nor local binaries, acceptance is explicitly skipped and must not be called complete.

On 2026-10-16, the package passed **9 tests, 0 failures, 0 skips** against a newly initialized local PostgreSQL 18 instance, plus package TypeScript checking. These executed the actual migration CLI, replay/history checks, a failed-file rollback, fail-fast concurrency, real non-superuser RLS/grants, tenant isolation, optimistic progress conflicts, idempotent events and audit-failure rollback. Remote migration, live identity handoff, production database permissions, provider recovery, payment/content access, and production capacity remain unverified.

## Ownership and runtime boundary

Source is owned by `Microservices/learning-service`, separately from consuming web/mobile applications and product façades. The existing native modular-monolith registry and pure edge common API are unchanged. This package is a tested domain/persistence library, not a newly deployed listener or a registered 55th module. A future native/edge adapter must reuse current tenant/identity/authorization services and pass its own readiness/integration acceptance. Pure edge Consumers require a deliberate Node-compatible Hyperdrive adapter; this package must not be imported blindly into a Worker without nodejs_compat.
