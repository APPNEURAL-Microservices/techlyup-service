-- Reusable learning domain only. No credentials, profiles, payments,
-- catalog copies, website-table alterations, or account migrations.
CREATE TABLE learning_core.account_refs (
 org_id text NOT NULL CHECK(length(org_id) BETWEEN 1 AND 180),
 account_id text NOT NULL CHECK(length(account_id) BETWEEN 1 AND 180),
 issuer text NOT NULL DEFAULT 'canonical' CHECK(length(issuer) BETWEEN 1 AND 180),
 created_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(org_id,account_id)
);
COMMENT ON TABLE learning_core.account_refs IS 'External canonical subject references only. An existing ID is not proof of current authentication, account status, registration or payment entitlement.';
CREATE TABLE learning_core.learning_enrollments (
 id uuid PRIMARY KEY,
 org_id text NOT NULL,
 account_id text NOT NULL,
 item_kind text NOT NULL CHECK(item_kind IN ('course','webinar','mentorship','career')),
 item_ref text NOT NULL CHECK(length(item_ref) BETWEEN 1 AND 180),
 status text NOT NULL DEFAULT 'active' CHECK(status IN ('active','completed','withdrawn')),
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(org_id,account_id,item_kind,item_ref),
 UNIQUE(org_id,account_id,id),
 FOREIGN KEY(org_id,account_id) REFERENCES learning_core.account_refs(org_id,account_id)
);
CREATE INDEX learning_enrollments_owner_recent ON learning_core.learning_enrollments(org_id,account_id,created_at DESC,id);
COMMENT ON TABLE learning_core.learning_enrollments IS 'App learning tracking only. Never grants canonical paid course, registration, live media or certificate entitlement.';
CREATE TABLE learning_core.learning_progress (
 org_id text NOT NULL,
 account_id text NOT NULL,
 enrollment_id uuid NOT NULL,
 lesson_ref text NOT NULL CHECK(length(lesson_ref) BETWEEN 1 AND 180),
 status text NOT NULL CHECK(status IN ('started','completed')),
 version integer NOT NULL DEFAULT 1 CHECK(version>0),
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(org_id,account_id,enrollment_id,lesson_ref),
 FOREIGN KEY(org_id,account_id,enrollment_id) REFERENCES learning_core.learning_enrollments(org_id,account_id,id)
);
CREATE TABLE learning_core.audit_events (
 id uuid PRIMARY KEY,
 org_id text NOT NULL,
 account_id text NOT NULL,
 request_id text NOT NULL CHECK(length(request_id) BETWEEN 1 AND 180),
 action text NOT NULL CHECK(action IN ('learning.enrolled','learning.progress_saved')),
 aggregate_id uuid NOT NULL,
 metadata jsonb NOT NULL DEFAULT '{}'::jsonb CHECK(jsonb_typeof(metadata)='object'),
 created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(org_id,account_id) REFERENCES learning_core.account_refs(org_id,account_id)
);
CREATE INDEX audit_events_owner_recent ON learning_core.audit_events(org_id,account_id,created_at DESC,id);
CREATE TABLE learning_core.analytics_events (
 event_id uuid NOT NULL,
 org_id text NOT NULL,
 account_id text NOT NULL,
 event_name text NOT NULL CHECK(event_name ~ '^[a-z][a-z0-9_.-]{0,63}$'),
 screen text NOT NULL CHECK(screen ~ '^[a-z][a-z0-9_.-]{0,63}$'),
 item_kind text CHECK(item_kind IN ('course','webinar','mentorship','career')),
 request_sha256 text NOT NULL CHECK(length(request_sha256)=64),
 created_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(org_id,account_id,event_id),
 FOREIGN KEY(org_id,account_id) REFERENCES learning_core.account_refs(org_id,account_id)
);
CREATE INDEX analytics_events_recent ON learning_core.analytics_events(org_id,created_at DESC,event_id);
CREATE TABLE learning_core.idempotency_operations (
 org_id text NOT NULL,
 account_id text NOT NULL,
 operation_key uuid NOT NULL,
 operation_kind text NOT NULL CHECK(operation_kind IN ('enroll','save_progress')),
 request_sha256 text NOT NULL CHECK(length(request_sha256)=64),
 result jsonb NOT NULL CHECK(jsonb_typeof(result)='object'),
 created_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(org_id,account_id,operation_key),
 FOREIGN KEY(org_id,account_id) REFERENCES learning_core.account_refs(org_id,account_id)
);
CREATE INDEX idempotency_operations_age ON learning_core.idempotency_operations(created_at);
-- Runtime enforcement supplements mandatory owner scoping in the repository.
-- Missing context denies all rows. A trusted service still controls its own
-- session context; RLS does not replace authentication or API authorization.
ALTER TABLE learning_core.account_refs ENABLE ROW LEVEL SECURITY;
ALTER TABLE learning_core.account_refs FORCE ROW LEVEL SECURITY;
CREATE POLICY account_ref_owner ON learning_core.account_refs USING(org_id=current_setting('techlyup.org_id',true) AND account_id=current_setting('techlyup.account_id',true)) WITH CHECK(org_id=current_setting('techlyup.org_id',true) AND account_id=current_setting('techlyup.account_id',true));
ALTER TABLE learning_core.learning_enrollments ENABLE ROW LEVEL SECURITY;
ALTER TABLE learning_core.learning_enrollments FORCE ROW LEVEL SECURITY;
CREATE POLICY enrollment_owner ON learning_core.learning_enrollments USING(org_id=current_setting('techlyup.org_id',true) AND account_id=current_setting('techlyup.account_id',true)) WITH CHECK(org_id=current_setting('techlyup.org_id',true) AND account_id=current_setting('techlyup.account_id',true));
ALTER TABLE learning_core.learning_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE learning_core.learning_progress FORCE ROW LEVEL SECURITY;
CREATE POLICY progress_owner ON learning_core.learning_progress USING(org_id=current_setting('techlyup.org_id',true) AND account_id=current_setting('techlyup.account_id',true)) WITH CHECK(org_id=current_setting('techlyup.org_id',true) AND account_id=current_setting('techlyup.account_id',true));
ALTER TABLE learning_core.audit_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE learning_core.audit_events FORCE ROW LEVEL SECURITY;
CREATE POLICY audit_owner ON learning_core.audit_events USING(org_id=current_setting('techlyup.org_id',true) AND account_id=current_setting('techlyup.account_id',true)) WITH CHECK(org_id=current_setting('techlyup.org_id',true) AND account_id=current_setting('techlyup.account_id',true));
ALTER TABLE learning_core.analytics_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE learning_core.analytics_events FORCE ROW LEVEL SECURITY;
CREATE POLICY analytics_owner ON learning_core.analytics_events USING(org_id=current_setting('techlyup.org_id',true) AND account_id=current_setting('techlyup.account_id',true)) WITH CHECK(org_id=current_setting('techlyup.org_id',true) AND account_id=current_setting('techlyup.account_id',true));
ALTER TABLE learning_core.idempotency_operations ENABLE ROW LEVEL SECURITY;
ALTER TABLE learning_core.idempotency_operations FORCE ROW LEVEL SECURITY;
CREATE POLICY operations_owner ON learning_core.idempotency_operations USING(org_id=current_setting('techlyup.org_id',true) AND account_id=current_setting('techlyup.account_id',true)) WITH CHECK(org_id=current_setting('techlyup.org_id',true) AND account_id=current_setting('techlyup.account_id',true));
