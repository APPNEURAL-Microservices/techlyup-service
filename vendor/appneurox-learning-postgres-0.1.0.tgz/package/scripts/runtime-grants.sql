-- Reviewed template for an operator, NEVER an automatic deployment migration.
-- Provision a distinct login externally with verified TLS. Replace the literal
-- role learning_core_runtime with its reviewed identifier before executing.
-- Keep the runtime login NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE.
GRANT USAGE ON SCHEMA learning_core TO learning_core_runtime;
GRANT SELECT,INSERT ON learning_core.account_refs TO learning_core_runtime;
GRANT SELECT,INSERT ON learning_core.learning_enrollments TO learning_core_runtime;
-- PostgreSQL row-locking SELECT needs UPDATE on at least one column.
GRANT UPDATE(updated_at) ON learning_core.learning_enrollments TO learning_core_runtime;
GRANT SELECT,INSERT,UPDATE ON learning_core.learning_progress TO learning_core_runtime;
GRANT SELECT,INSERT ON learning_core.audit_events TO learning_core_runtime;
GRANT SELECT,INSERT ON learning_core.analytics_events TO learning_core_runtime;
GRANT SELECT,INSERT ON learning_core.idempotency_operations TO learning_core_runtime;
-- No schema creation, table ownership, migration ledger access, DELETE,
-- cross-account maintenance or audit UPDATE/DELETE is granted here.
