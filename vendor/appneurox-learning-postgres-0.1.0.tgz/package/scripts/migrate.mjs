import { fileURLToPath } from 'node:url';
import pg from 'pg';
import { executeLearningMigrations, LearningMigrationError, migrationMode, readLearningMigrations } from './lib/migrations.mjs';

let client;
try {
  const mode = migrationMode(process.argv.slice(2));
  const migrations = await readLearningMigrations(fileURLToPath(new URL('../migrations/', import.meta.url)));
  if (mode === 'plan') {
    console.log(JSON.stringify({ mode: 'plan-only', target: 'Reusable learning_core schema; existing identity/application data unchanged', migrations: migrations.map(({ name, sha256 }) => ({ name, sha256 })) }, null, 2));
  } else {
    const connectionString = process.env.LEARNING_POSTGRES_MIGRATION_URL;
    if (!connectionString) throw new LearningMigrationError('migration_url_required');
    client = new pg.Client({ connectionString, connectionTimeoutMillis: 5000 });
    await client.connect();
    const result = await executeLearningMigrations(client, migrations, mode);
    console.log(JSON.stringify(result, null, 2));
    if (!result.success) process.exitCode = 1;
  }
} catch (error) {
  const code = error instanceof LearningMigrationError ? error.code : 'database_or_migration_failed';
  console.error(`Learning migration failed (${code}). Inspect private database logs.`);
  process.exitCode = 1;
} finally { if (client) await client.end().catch(() => undefined); }
