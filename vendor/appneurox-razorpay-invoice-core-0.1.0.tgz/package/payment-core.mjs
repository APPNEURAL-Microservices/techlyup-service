export class PaymentError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
export async function hash(value) {
  return [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value)))].map(n => n.toString(16).padStart(2,'0')).join('');
}
export async function validSignature(secret, value, signature) {
  if (typeof signature !== 'string' || !/^[a-f0-9]{64}$/i.test(signature)) return false;
  const key = await crypto.subtle.importKey('raw',new TextEncoder().encode(secret),{name:'HMAC',hash:'SHA-256'},false,['verify']);
  return crypto.subtle.verify('HMAC',key,Uint8Array.from(signature.match(/../g),n=>parseInt(n,16)),new TextEncoder().encode(value));
}
export function configuration(env) {
  const mode = env.RAZORPAY_MODE === 'test' ? 'test' : 'live';
  const keyId = env.RAZORPAY_KEY_ID || '';
  const ready = ['test','live'].includes(env.RAZORPAY_MODE) && Boolean(env.PAYMENTS_DB && env.RATE_LIMIT && new RegExp(`^rzp_${mode}_[A-Za-z0-9]+$`).test(keyId) && env.RAZORPAY_KEY_SECRET && env.RAZORPAY_WEBHOOK_SECRET);
  return {
    mode, keyId, ready, secret:env.RAZORPAY_KEY_SECRET || '', webhookSecret:env.RAZORPAY_WEBHOOK_SECRET || '',
    available:ready && env.PAYMENTS_ENABLED === 'true',
  };
}
/** Resolve collection permissions from exact merchant-verified host evidence. */
export async function checkoutReadiness(env, config, site, hostname, approvals, now = Date.now()) {
  const centralCheckoutHost = typeof env.CHECKOUT_HOST === 'string' ? env.CHECKOUT_HOST : '';
  const localTest = config.mode === 'test' && !centralCheckoutHost && ['localhost','127.0.0.1','[::1]'].includes(hostname);
  const centralReceiver = Boolean(centralCheckoutHost && hostname === centralCheckoutHost) || localTest;
  let records = approvals;
  // This binding exists only for isolated server-side Test fixtures. Visitor
  // request fields cannot override approvals, and Live always ignores it.
  if (config.mode === 'test' && typeof env.DIRECT_CHECKOUT_APPROVALS_TEST_OVERRIDE === 'string') {
    try { records = JSON.parse(env.DIRECT_CHECKOUT_APPROVALS_TEST_OVERRIDE); }
    catch { records = null; }
  }
  const candidates = records?.schemaVersion === 1 && Array.isArray(records.approvals)
    ? records.approvals.filter(record => record && record.host === hostname && record.site === site.domain && record.mode === config.mode) : [];
  const record = candidates.length === 1 ? candidates[0] : null;
  const verifiedAt = typeof record?.verifiedAt === 'string' ? Date.parse(record.verifiedAt) : NaN;
  const approved = Boolean(record && record.status === 'approved' && typeof config.keyId === 'string' && new RegExp(`^rzp_${config.mode}_[A-Za-z0-9]+$`).test(config.keyId) && /^[a-f0-9]{64}$/i.test(record.keyIdHash || '')
    && Number.isFinite(verifiedAt) && verifiedAt <= now + 300000 && typeof record.evidence === 'string' && record.evidence.trim()
    && record.keyIdHash.toLowerCase() === await hash(config.keyId));
  const directCheckout = localTest || approved;
  return {
    directCheckout, centralReceiver, directApprovalPending: !directCheckout,
    checkoutModel: directCheckout ? 'direct' : 'centralized',
    checkoutHost: localTest ? '' : directCheckout ? hostname : centralCheckoutHost,
    centralCheckoutHost, merchantName: 'APPNEURAL',
  };
}
export function provider(config, fetcher = (input,init)=>fetch(input,init)) {
  return async (path, body) => {
    let response;
    try {
      response = await fetcher('https://api.razorpay.com/v1'+path,{
        method:body ? 'POST':'GET', headers:{Authorization:'Basic '+btoa(config.keyId+':'+config.secret),'Content-Type':'application/json'},
        ...(body ? {body:JSON.stringify(body)}:{}), signal:AbortSignal.timeout(12000), redirect:'manual',
      });
    } catch(error) {
      const safeMessage=String(error?.message || '').replaceAll(config.secret,'[redacted]').replaceAll(config.keyId,'[redacted]').slice(0,240);
      console.error(JSON.stringify({event:'razorpay_transport_failure',operation:body?'create-order':'read',errorType:error?.name || 'Error',message:safeMessage}));
      throw new PaymentError(503,'Payment confirmation is taking longer. Check this payment again before trying to pay.');
    }
    if (!response.ok) {
      console.error(JSON.stringify({event:'razorpay_http_failure',operation:body?'create-order':'read',status:response.status}));
      throw new PaymentError(503,'The payment provider could not confirm this request. Check this payment again before trying to pay.');
    }
    try { return await response.json(); } catch { throw new PaymentError(502,'Payment confirmation is unavailable. Please check this payment again.'); }
  };
}
export function publicInvoice(row) {
  return {
    id:row.id, website:row.site, reference:row.reference_label, title:row.title, description:row.description,
    amount:row.amount, currency:row.currency, status:row.status, mode:row.mode,
    providerOrderId:row.provider_order_id, paymentId:row.payment_id, customerName:row.customer_name,
    email:row.email, amountRefunded:row.amount_refunded, expiresAt:row.expires_at,
  };
}
export async function lookup(db, site, mode, reference, email, owner, now = Date.now()) {
  if (typeof reference !== 'string' || !/^INV-[a-f0-9]{32}$/i.test(reference.trim()) || typeof email !== 'string' || email.length > 254)
    throw new PaymentError(404,'Payment reference and email do not match. Check the details shared with you.');
  const row = await db.prepare('SELECT * FROM invoices WHERE site=? AND mode=? AND reference_hash=? AND email_hash=?')
    .bind(site,mode,await hash(reference.trim().toUpperCase()),await hash(email.trim().toLowerCase())).first();
  if (!row) throw new PaymentError(404,'Payment reference and email do not match. Check the details shared with you.');
  await db.prepare('INSERT INTO invoice_access(invoice_id,owner_hash,expires_at) VALUES(?,?,?) ON CONFLICT(invoice_id,owner_hash) DO UPDATE SET expires_at=excluded.expires_at')
    .bind(row.id,owner,now+30*86400000).run();
  return row;
}
export async function ownedInvoice(db, id, site, mode, owner, now = Date.now(), centralCheckout = false) {
  if (typeof id !== 'string' || !/^[a-f0-9-]{36}$/.test(id)) throw new PaymentError(400,'Invalid payment reference.');
  const row = await db.prepare('SELECT i.* FROM invoices i JOIN invoice_access a ON a.invoice_id=i.id WHERE i.id=? AND (?=1 OR i.site=?) AND i.mode=? AND a.owner_hash=? AND a.expires_at>?')
    .bind(id,Number(centralCheckout),site,mode,owner,now).first();
  if (!row) throw new PaymentError(404,'Open this payment with your original reference and email.');
  return row;
}
export async function createOrder(db, config, call, row, now = Date.now()) {
  if (!config.available || row.mode !== config.mode) throw new PaymentError(503,'Online payments are not available yet. Please contact the team for your invoice.');
  if (row.key_id && row.key_id !== config.keyId) throw new PaymentError(503,'This payment needs a team review before you continue.');
  if (['paid','partially_refunded','refunded'].includes(row.status)) return row;
  if (row.expires_at <= now) throw new PaymentError(410,'This payment reference has expired. Please ask the team for an updated invoice.');
  if (row.provider_order_id) return row;
  if (row.status !== 'open') throw new PaymentError(409,'Your order is being checked. Use Check payment status before trying to pay.');
  const claim = await db.prepare("UPDATE invoices SET status='creating',key_id=?,updated_at=? WHERE id=? AND status='open' AND provider_order_id IS NULL")
    .bind(config.keyId,now,row.id).run();
  if (claim.meta.changes !== 1) throw new PaymentError(409,'Your order is being checked. Use Check payment status before trying to pay.');
  // Persist before remote POST. An uncertain response never triggers another order creation.
  const result = await call('/orders',{
    amount:row.amount,currency:row.currency,receipt:row.id,partial_payment:false,
    notes:{invoice_id:row.id,website:row.site,reference:row.reference_label},
  });
  if (!/^order_[A-Za-z0-9]+$/.test(result?.id || '') || result.amount !== row.amount || result.currency !== row.currency || result.receipt !== row.id)
    throw new PaymentError(502,'This payment needs to be checked. Please contact the team before trying again.');
  await db.prepare("UPDATE invoices SET provider_order_id=?,status='pending',updated_at=? WHERE id=? AND status='creating'").bind(result.id,now,row.id).run();
  return db.prepare('SELECT * FROM invoices WHERE id=?').bind(row.id).first();
}
export async function reconcile(db, config, call, row, paymentId, now = Date.now()) {
  if (!row.provider_order_id) return row;
  if (!(config.ready ?? config.available) || row.key_id !== config.keyId || row.mode !== config.mode) throw new PaymentError(503,'Payment verification is temporarily unavailable.');
  let payment;
  if (paymentId) {
    if (!/^pay_[A-Za-z0-9]+$/.test(paymentId)) throw new PaymentError(400,'Invalid payment reference.');
    if (row.payment_id && row.payment_id !== paymentId) throw new PaymentError(409,'This invoice is already linked to a different payment. Please contact the team.');
    payment = await call('/payments/'+paymentId);
  } else {
    const result = await call('/orders/'+row.provider_order_id+'/payments');
    const items = Array.isArray(result?.items) ? result.items : [];
    payment = items.find(p=>p.id===row.payment_id) || items.find(p=>['captured','refunded'].includes(p.status));
  }
  if (!payment) return row;
  if (payment.order_id !== row.provider_order_id || payment.amount !== row.amount || payment.currency !== row.currency || !/^pay_[A-Za-z0-9]+$/.test(payment.id || '') || (paymentId && payment.id !== paymentId) || (row.payment_id && row.payment_id !== payment.id))
    throw new PaymentError(409,'Payment details do not match this invoice.');
  if (!['captured','refunded'].includes(payment.status)) return row;
  const order = await call('/orders/'+row.provider_order_id);
  if (order.id !== row.provider_order_id || order.receipt !== row.id || order.amount !== row.amount || order.currency !== row.currency || order.status !== 'paid' || order.amount_paid !== row.amount)
    throw new PaymentError(409,'The provider has not confirmed this invoice as paid. Please check again shortly.');
  const refunded = payment.amount_refunded ?? 0;
  if (!Number.isSafeInteger(refunded) || refunded < 0 || refunded > row.amount || (payment.status === 'refunded' && refunded !== row.amount))
    throw new PaymentError(409,'Refund details need to be checked by the team.');
  // Monotonic refund state: delayed capture callbacks cannot restore a refunded invoice.
  await db.prepare(`UPDATE invoices SET payment_id=?,amount_refunded=MAX(amount_refunded,?),
    status=CASE WHEN MAX(amount_refunded,?)=amount THEN 'refunded' WHEN MAX(amount_refunded,?)>0 THEN 'partially_refunded' ELSE 'paid' END,
    updated_at=? WHERE id=? AND (payment_id IS NULL OR payment_id=?)`)
    .bind(payment.id,refunded,refunded,refunded,now,row.id,payment.id).run();
  const updated = await db.prepare('SELECT * FROM invoices WHERE id=?').bind(row.id).first();
  if (!updated || updated.payment_id !== payment.id) throw new PaymentError(409,'This invoice is already linked to a different payment. Please contact the team.');
  return updated;
}
export async function verifyPayment(db, config, call, row, input) {
  if (!row.provider_order_id || input.razorpay_order_id !== row.provider_order_id || typeof input.razorpay_payment_id !== 'string') throw new PaymentError(409,'Payment details do not match this invoice.');
  if (!await validSignature(config.secret,row.provider_order_id+'|'+input.razorpay_payment_id,input.razorpay_signature)) throw new PaymentError(400,'Payment signature could not be verified.');
  return reconcile(db,config,call,row,input.razorpay_payment_id);
}
export async function webhook(db, config, call, body, signature, eventId) {
  if (!await validSignature(config.webhookSecret,body,signature)) throw new PaymentError(400,'Invalid webhook signature.');
  const digest = await hash(body);
  const id = eventId || digest;
  if (id.length > 200) throw new PaymentError(400,'Invalid event reference.');
  const prior = await db.prepare('SELECT body_hash FROM payment_webhooks WHERE event_id=?').bind(id).first();
  if (prior) {
    if (prior.body_hash !== digest) throw new PaymentError(409,'Webhook event content changed.');
    return {received:true,replayed:true};
  }
  let event;
  try { event=JSON.parse(body); } catch { throw new PaymentError(400,'Invalid webhook payload.'); }
  const entity = event?.payload?.payment?.entity;
  const orderId = entity?.order_id || event?.payload?.order?.entity?.id;
  if (['payment.captured','payment.authorized','order.paid','refund.created','refund.processed','payment.refunded'].includes(event?.event) && /^order_[A-Za-z0-9]+$/.test(orderId || '')) {
    const row = await db.prepare('SELECT * FROM invoices WHERE provider_order_id=? AND mode=?').bind(orderId,config.mode).first();
    if (row) await reconcile(db,config,call,row,entity?.id);
  } else if (['refund.created','refund.processed'].includes(event?.event)) {
    const paymentId=event?.payload?.refund?.entity?.payment_id;
    if (/^pay_[A-Za-z0-9]+$/.test(paymentId || '')) {
      const p=await call('/payments/'+paymentId);
      const row=await db.prepare('SELECT * FROM invoices WHERE provider_order_id=? AND mode=?').bind(p.order_id || '',config.mode).first();
      if(row) await reconcile(db,config,call,row,paymentId);
    }
  }
  await db.prepare('INSERT OR IGNORE INTO payment_webhooks(event_id,body_hash,processed_at) VALUES(?,?,?)').bind(id,digest,Date.now()).run();
  return {received:true};
}
