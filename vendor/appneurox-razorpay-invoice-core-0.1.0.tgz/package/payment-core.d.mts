export interface Invoice {id:string;site:string;mode:string;status:string;amount:number;currency:string;provider_order_id:string|null;payment_id:string|null;key_id:string|null;amount_refunded:number;expires_at:number;[key:string]:unknown}
export interface CoreConfig {mode:'test'|'live';keyId:string;secret:string;webhookSecret:string;available:boolean;ready?:boolean}
export interface CoreDatabase {prepare(query:string):any}
export type ProviderCall=(path:string,body?:unknown)=>Promise<any>;
export class PaymentError extends Error {status:number;constructor(status:number,message:string)}
export function hash(value:string):Promise<string>;
export function validSignature(secret:string,value:string,signature:string):Promise<boolean>;
export function createOrder(db:CoreDatabase,config:CoreConfig,call:ProviderCall,row:Invoice,now?:number):Promise<Invoice>;
export function reconcile(db:CoreDatabase,config:CoreConfig,call:ProviderCall,row:Invoice,paymentId?:string,now?:number):Promise<Invoice>;
export function verifyPayment(db:CoreDatabase,config:CoreConfig,call:ProviderCall,row:Invoice,input:{razorpay_order_id:string;razorpay_payment_id:string;razorpay_signature:string}):Promise<Invoice>;
export function webhook(db:CoreDatabase,config:CoreConfig,call:ProviderCall,body:string,signature:string,eventId:string):Promise<{received:boolean;replayed?:boolean}>;
export function provider(config:CoreConfig,fetcher?:typeof fetch):ProviderCall;
